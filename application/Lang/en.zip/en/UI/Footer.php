<?php 
$lang['Footer'] = array(
    'Homepage' => 'Homepage',
    'Forum' => 'Forum',
    'Links' => 'Links',
    'FAQ' => 'FAQ - Answers',
    'Terms' => 'Terms',
    'Imprint' => 'Imprint',
);