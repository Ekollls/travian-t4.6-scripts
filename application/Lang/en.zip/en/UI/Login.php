<?php 
$lang['login'] = array(
    'Welcome' => 'Welcome to server',
    'Username' => 'Account name or e-mail address',
    'Password' => 'Password',

    'Notice1' => 'Version for player',
    'Notice2' => 'with low bandwidth (internet connection speed)',
    'Notice3' => '(Note: this version of the map doesn\'t have all the options enabled)',

    'Login' => 'Login',

    'ForgetPW1' => 'Password Forgotten?',
    'ForgetPW2' => 'We will send you a new password. It will be activated as soon as you confirm receipt',
    'ForgetPW3' => 'Email',
    'ForgetPW4' => 'Request password',
);