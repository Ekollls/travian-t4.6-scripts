<?php 
$lang['Options'] = array(
    'TZ01' => 'Time zone preferences',
    'TZ02' => 'You can change your time zone here.',
    'TZ03' => 'Time zone',
    'TZ04' => 'Date format',
);

