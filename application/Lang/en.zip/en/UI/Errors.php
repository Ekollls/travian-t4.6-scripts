<?php

$lang['Errors'] = array(
    'Error01' => 'You can\'t access here since you\'re account is in deletion process.',
    'Error02' => 'Finish 10 adventures to unlock the auctions.',
    'Error03' => 'Finish adventures',
);