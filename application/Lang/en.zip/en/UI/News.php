<?php
$lang['News'] = array(
    '1' => 'Plus account will expire in',
    '2' => 'Wood production bonus will expire in in',
    '3' => 'Clay production bonus will expire in in',
    '4' => 'Iron production bonus will expire in in',
    '5' => 'Crop production bonus will expire in in',

    '1F' => 'Your plus account has expired.',
    '2F' => 'Wood production bonus has expired.',
    '3F' => 'Clay production bonus has expired.',
    '4F' => 'Iron production bonus has expired.',
    '5F' => 'Crop production bonus has expired.',

    'Button01' => 'Extend Now',
    'Button02' => 'Bonus duration in hours',
    'Button03' => 'hour',
    'Button04' => 'Extend',

    'Hour' => 'hours',

    'Arts' => 'Artifacts will be released in %s hours',
    'WWPlans' => 'Construction plans will appear in %s hours',
);