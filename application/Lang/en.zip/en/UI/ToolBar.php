<?php 
$lang['Toolbar'] = array(
    '01' => 'Profile||Edit profile description.',
    '02' => 'Options||Edit account settings.',
    '03' => 'Forum||Meet other players on our external forum.',
    '04' => 'Help||Manuals, Answers and Support',
    '05' => 'Logout||Log out from the game.',
);