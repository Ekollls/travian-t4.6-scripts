<?php 
$lang['Support'] = array(
    '01' => 'Support',
    '02' => 'You can use the following form to submit your request to the Support. Please take a bit of time to answer the form questions in as much detail as possible, so that we can answer your request quickly and in length. Please note that without a valid email address, your request will not get processed',
    '03' => 'Game errors, login errors and game rules related questions',
    '04' => 'Game world',
    '05' => 'Username',
    '06' => 'Email',
    '07' => 'Category',
    '08' => 'Message',
    '09' => 'Captcha',
    '10' => 'send request',
);